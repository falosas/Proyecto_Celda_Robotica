#include <time.h>

// Estado global de enclavamiento
bool alarma_ON = false;
bool sistema_ON = false;

// Variables para el botón de Marcha (NO)
int estado_marcha = HIGH;
int ultimo_estado_marcha = HIGH;
unsigned long ultimo_rebote_marcha = 0;

// Variables Puerta (Normalmente Abierto - NO) -> Seguro: HIGH, Alarma: LOW
int estado_puerta = HIGH;
int ultimo_estado_puerta = HIGH;
unsigned long ultimo_rebote_puerta = 0;

// Variables Reset (Normalmente Abierto - NO) -> Reposo: HIGH, Pulsado: LOW
int estado_reset = HIGH;
int ultimo_estado_reset = HIGH;
unsigned long ultimo_rebote_reset = 0;

// Variables E-Stop (Normalmente Cerrado - NC) -> Seguro: LOW, Alarma: HIGH (Circuito abierto)
int estado_emergencia = HIGH;
int ultimo_estado_emergencia = HIGH;
unsigned long ultimo_rebote_emergencia = 0;

// Variables de telemetría analógica
unsigned long ultimo_envio_telemetria = 0;
const int intervalo_telemetria = 5000; // Enviar datos cada 5 segundos
int luz_actual = 0;

const int retardo_rebote = 50;

void on_loop() 
{
    unsigned long tiempo_actual = millis();
    int lectura_puerta = digitalRead(PIN_BOTON_PUERTA);
    int lectura_reset = digitalRead(PIN_RESET);
    int lectura_emergencia = digitalRead(PIN_EMERGENCIA);
    int lectura_marcha = digitalRead(PIN_BOTON_MARCHA);

    /*/ --- 1. EVALUACIÓN PARADA DE EMERGENCIA (NC) ---
    if (lectura_emergencia != ultimo_estado_emergencia) ultimo_rebote_emergencia = tiempo_actual;
    if ((tiempo_actual - ultimo_rebote_emergencia) > retardo_rebote) 
    {
        if (lectura_emergencia != estado_emergencia) 
        {
            estado_emergencia = lectura_emergencia;
            
            // Flanco de subida (Circuito roto o Seta pulsada = HIGH)
            if (estado_emergencia == HIGH && !alarma_ON) 
            {
                infoln("¡CRÍTICO! Seta de emergencia activada o cable cortado.");
                alarma_ON = true;
                sistema_ON = false;

                digitalWrite(PIN_LED_ALARMA, HIGH);
                digitalWrite(PIN_LED_MARCHA, LOW);
                digitalWrite(PIN_ACTUADOR, LOW);

                JsonDocument doc;
                doc["dispositivo"] = "seta_emergencia";
                doc["evento"] = "activacion";
                doc["alarma"] = true;
                
                String payload;
                serializeJson(doc, payload);
                enviarMensajePorTopic(SENSOR_TOPIC, payload); // Reutilizamos el topic de seguridad

                infoln("RED: Publicando orden de PARADA INMEDIATA a esclavos.");
                JsonDocument docAbort;
                docAbort["dispositivo"] = "master_plc";
                docAbort["accion"] = "apagar";
                docAbort["valor"] = 0;
                String payloadAbort;
                serializeJson(docAbort, payloadAbort);
                
                enviarMensajePorTopic(ACTUADOR_TOPIC, payloadAbort);
            }
        }
    }
    ultimo_estado_emergencia = lectura_emergencia;
    */

    // --- 1. EVALUACIÓN PARADA DE EMERGENCIA (NA) ---
    if (lectura_emergencia != ultimo_estado_emergencia) ultimo_rebote_emergencia = tiempo_actual;
    if ((tiempo_actual - ultimo_rebote_emergencia) > retardo_rebote) 
    {
        if (lectura_emergencia != estado_emergencia) 
        {
            estado_emergencia = lectura_emergencia;
            
            // Flanco de bajada (Botón pulsado = LOW)
            if (estado_emergencia == LOW && !alarma_ON) 
            {
                infoln("¡CRÍTICO! Seta de emergencia activada.");
                alarma_ON = true;
                sistema_ON = false;

                digitalWrite(PIN_ACTUADOR, LOW); 
                digitalWrite(PIN_LED_ALARMA, HIGH);
                digitalWrite(PIN_ALARMA, HIGH);
                digitalWrite(PIN_LED_MARCHA, LOW);

                JsonDocument doc;
                doc["dispositivo"] = "seta_emergencia";
                doc["evento"] = "activacion";
                doc["alarma"] = true;
                
                String payload;
                serializeJson(doc, payload);
                enviarMensajePorTopic(SENSOR_TOPIC, payload);

                infoln("RED: Publicando orden de PARADA INMEDIATA a esclavos.");
                JsonDocument docAbort;
                docAbort["dispositivo"] = "master_plc";
                docAbort["accion"] = "apagar";
                docAbort["valor"] = 0;
                String payloadAbort;
                serializeJson(docAbort, payloadAbort);
                
                enviarMensajePorTopic(ACTUADOR_TOPIC, payloadAbort);
                registroSD("EMERGENCIA", "Seta de emergencia activada.");
            }
        }
    }
    ultimo_estado_emergencia = lectura_emergencia;

    // --- 2. EVALUACIÓN PUERTA JAULA (NO) ---
    if (lectura_puerta != ultimo_estado_puerta) ultimo_rebote_puerta = tiempo_actual;
    if ((tiempo_actual - ultimo_rebote_puerta) > retardo_rebote) 
    {
        if (lectura_puerta != estado_puerta) 
        {
            estado_puerta = lectura_puerta;
            
            if (estado_puerta == LOW && !alarma_ON) 
            {
                infoln("¡EMERGENCIA! Puerta abierta.");
                alarma_ON = true;
                sistema_ON = false;

                digitalWrite(PIN_LED_ALARMA, HIGH);
                digitalWrite(PIN_ALARMA, HIGH);
                digitalWrite(PIN_LED_MARCHA, LOW);
                digitalWrite(PIN_ACTUADOR, LOW);

                JsonDocument doc;
                doc["dispositivo"] = "puerta_jaula";
                doc["evento"] = "apertura";
                doc["alarma"] = true;
                
                String payload;
                serializeJson(doc, payload);
                enviarMensajePorTopic(SENSOR_TOPIC, payload);

                infoln("RED: Publicando orden de PARADA INMEDIATA a esclavos.");
                JsonDocument docAbort;
                docAbort["dispositivo"] = "master_plc";
                docAbort["accion"] = "apagar";
                docAbort["valor"] = 0;
                String payloadAbort;
                serializeJson(docAbort, payloadAbort);
                
                enviarMensajePorTopic(ACTUADOR_TOPIC, payloadAbort);
                registroSD("INTRUSION", "Puerta abierta.");
            }
        }
    }
    ultimo_estado_puerta = lectura_puerta;

    // --- 3. EVALUACIÓN REARME (RESET - NO) ---
    if (lectura_reset != ultimo_estado_reset) ultimo_rebote_reset = tiempo_actual;
    if ((tiempo_actual - ultimo_rebote_reset) > retardo_rebote) 
    {
        if (lectura_reset != estado_reset) 
        {
            estado_reset = lectura_reset;
            
            // Se pulsa el reset
            if (estado_reset == LOW) 
            {
                // La puerta debe estar cerrada (HIGH) Y la seta liberada (LOW) (Caso seta NC)
                //if (estado_puerta == HIGH && estado_emergencia == LOW && alarma_ON) {
                if (estado_puerta == HIGH && estado_emergencia == HIGH && alarma_ON) 
                {
                    infoln("INFO: Todos los bloqueos despejados. Sistema rearmado.");
                    alarma_ON = false;

                    digitalWrite(PIN_LED_ALARMA, LOW);
                    digitalWrite(PIN_ALARMA, LOW);

                    JsonDocument doc;
                    doc["dispositivo"] = "sistema_seguridad";
                    doc["evento"] = "reset";
                    doc["alarma"] = false;
                    
                    String payload;
                    serializeJson(doc, payload);
                    enviarMensajePorTopic(SENSOR_TOPIC, payload);
                    registroSD("INFO", "Sistema rearmado por operario.");
                } 
                else if (alarma_ON) 
                {
                    warnln("DENEGADO: No se puede rearmar. Revisa la Seta y la Puerta.");
                    registroSD("INFO", "DENEGADO: No se puede rearmar. Revisa la Seta y la Puerta.");
                }
            }
        }
    }
    ultimo_estado_reset = lectura_reset;

    // --- 4. EVALUACIÓN DE MARCHA (NO) ---
    if (lectura_marcha != ultimo_estado_marcha) ultimo_rebote_marcha = tiempo_actual;
    if ((tiempo_actual - ultimo_rebote_marcha) > retardo_rebote) 
    {
        if (lectura_marcha != estado_marcha) 
        {
            estado_marcha = lectura_marcha;
            // Flanco de bajada (Botón pulsado)
            if (estado_marcha == LOW) 
            {
                // Solo se puede arrancar si NO hay alarmas y el sistema no está ya en marcha
                if (!alarma_ON && !sistema_ON) 
                {
                    infoln("PRODUCCIÓN: Sistema EN MARCHA.");
                    sistema_ON = true;

                    digitalWrite(PIN_LED_MARCHA, HIGH);

                    // 1. Aviso de estado operativo (el que ya tienes)
                    JsonDocument docEstado;
                    docEstado["dispositivo"] = "boton_marcha";
                    docEstado["evento"] = "inicio";
                    docEstado["alarma"] = false;
                    String payloadEstado;
                    serializeJson(docEstado, payloadEstado);
                    enviarMensajePorTopic(SENSOR_TOPIC, payloadEstado); 

                    // 2. NUEVO: ORDEN MAESTRA A LOS ACTUADORES (Cintas, etc.)
                    infoln("RED: Publicando orden de ARRANQUE a esclavos.");
                    JsonDocument docCmd;
                    docCmd["dispositivo"] = "master_plc";
                    docCmd["accion"] = "encender";
                    docCmd["valor"] = 1;
                    String payloadCmd;
                    serializeJson(docCmd, payloadCmd);
                    
                    // Publicamos en el canal de actuadores para que todo el mundo obedezca
                    enviarMensajePorTopic(ACTUADOR_TOPIC, payloadCmd);
                    registroSD("OPERACION", "Sistema EN MARCHA.");
                } 
                else if (alarma_ON) 
                {
                    warnln("DENEGADO: Intento de Marcha bloqueado por estado de Alarma.");
                    registroSD("INFO", "DENEGADO: Intento de Marcha bloqueado por estado de Alarma.");
                }
            }
        }
    }
    ultimo_estado_marcha = lectura_marcha;

    // --- 5. LECTURA ANALÓGICA: BARRERA DE LUZ Y TELEMETRÍA ---
    luz_actual = analogRead(PIN_LDR);

    // A. Evaluación de Seguridad 
    if (luz_actual < UMBRAL_SOMBRA && !alarma_ON) 
    {
        warnln("¡INTRUSIÓN! Caída de luz detectada (Sombra). Nivel: " + String(luz_actual));
        
        alarma_ON = true;
        sistema_ON = false;

        digitalWrite(PIN_ACTUADOR, LOW); 
        digitalWrite(PIN_LED_ALARMA, HIGH);
        digitalWrite(PIN_ALARMA, HIGH);
        digitalWrite(PIN_LED_MARCHA, LOW);

        JsonDocument doc;
        doc["dispositivo"] = "barrera_luz";
        doc["evento"] = "intrusion";
        doc["valor"] = luz_actual;
        doc["alarma"] = true;
        
        String payload;
        serializeJson(doc, payload);
        enviarMensajePorTopic(SENSOR_TOPIC, payload);

        // Apagar actuadores de la red
        JsonDocument docAbort;
        docAbort["dispositivo"] = "master_plc";
        docAbort["accion"] = "apagar";
        docAbort["valor"] = 0;
        String payloadAbort;
        serializeJson(docAbort, payloadAbort);
        enviarMensajePorTopic(ACTUADOR_TOPIC, payloadAbort);
        registroSD("INTRUSION", "Caída de luz detectada (Sombra). Nivel: " + String(luz_actual));
    }

    // B. Telemetría Periódica de Entorno (Sin interrumpir el procesador)
    if ((tiempo_actual - ultimo_envio_telemetria) > intervalo_telemetria) 
    {
        ultimo_envio_telemetria = tiempo_actual;

        // Solo publicamos el estado si el sistema está sano (opcional)
        JsonDocument docTelemetria;
        docTelemetria["dispositivo"] = "sensor_ambiente";
        docTelemetria["tipo"] = "iluminacion";
        docTelemetria["valor_crudo"] = luz_actual;
        
        String payloadTelemetria;
        serializeJson(docTelemetria, payloadTelemetria);
        
        // Publicamos en un topic nuevo dedicado a telemetría
        enviarMensajePorTopic(LDR_TOPIC, payloadTelemetria);
        
        infoln("Telemetría -> Nivel de luz ambiente: " + String(luz_actual));
    }
}

void registroSD(String evento, String mensaje) 
{
    struct tm timeinfo;
    String timestamp = "";

    // Intentamos obtener la hora real del procesador
    if (!getLocalTime(&timeinfo)) 
    {
        // Si no hay internet o NTP falló, usamos los milisegundos de encendido
        timestamp = "UPTIME:" + String(millis());
    } 
    else 
    {
        // Formateamos la hora al estándar industrial ISO 8601 (YYYY-MM-DD HH:MM:SS)
        char timeStringBuff[50];
        strftime(timeStringBuff, sizeof(timeStringBuff), "%Y-%m-%d %H:%M:%S", &timeinfo);
        timestamp = String(timeStringBuff);
    }

    // FILE_APPEND abre el archivo sin borrar lo anterior
    File archivo = SD_MMC.open("/registro_seguridad.txt", FILE_APPEND);
    
    if (archivo) 
    {
        archivo.print("[");
        archivo.print(timestamp);
        archivo.print("] [");
        archivo.print(tipo_evento);
        archivo.print("] -> ");
        archivo.println(mensaje);
        
        archivo.close(); 
    } 
    else 
    {
        Serial.println("ERROR CRÍTICO: Imposible escribir en registro_seguridad.txt vía SDMMC.");
    }
}