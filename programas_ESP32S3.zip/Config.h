// COMM BAUDS
#define BAUDS 115200
#define LOGGER_ENABLED            // Comentar para deshabilitar el logger por consola serie
#define LOG_LEVEL TRACE           // nivells en c_logger: TRACE, DEBUG, INFO, WARN, ERROR, FATAL, NONE

// DEVICE
//#define DEVICE_ESP_ID             "54CE0361421"   // ESP32 ID
#define DEVICE_CONTROLLER         "PLC" //"giirobpr2_00"

// WIFI
#define NET_SSID                  "MiFibra-26A0_Nilay"
#define NET_PASSWD                "DfVLijvw"

// MQTT
#define MQTT_SERVER_IP            "192.168.1.100"
#define MQTT_SERVER_PORT          1883
//#define MQTT_USERNAME             "giirob"    // Descomentar esta línea (y la siguiente) para que se conecte al broker MQTT usando usuario y contraseña
//#define MQTT_PASSWORD             "UPV2024"

#define SENSOR_TOPIC              "celda/seguridad/eventos"
#define ACTUADOR_TOPIC            "celda/actuadores/comandos"
#define LDR_TOPIC                 "celda/telemetria/celda1"

// IO
#define PIN_ACTUADOR              2
#define PIN_LED_ALARMA            4
#define PIN_LED_MARCHA            6
#define PIN_LDR                   9
#define PIN_BOTON_PUERTA          13
#define PIN_RESET                 14
#define PIN_EMERGENCIA            15
#define PIN_BOTON_MARCHA          16
#define PIN_ALARMA                17
#define SD_MMC_CMD                38 
#define SD_MMC_CLK                39 
#define SD_MMC_D0                 40 

//PARAMETERS
#define UMBRAL_SOMBRA             1500
#define NTP_SERVER                "pool.ntp.org"
#define GMT_OFFSET_SEC            3600      // Desfase base (España peninsular = +1 hora)
#define DAYLIGHT_OFFSET_SEC       3600 // Desfase por horario de verano (+1 hora)
