extern bool alarma_ON;
extern bool sistema_ON;

void suscribirseATopics() 
{
    mqtt_subscribe(ACTUADOR_TOPIC);
}

void alRecibirMensajePorTopic(char* topic, String incomingMessage) 
{
    // Filtramos solo los mensajes para nuestro actuador
    if (strcmp(topic, ACTUADOR_TOPIC) == 0) 
    {
        
        JsonDocument doc;
        DeserializationError err = deserializeJson(doc, incomingMessage);

        if (err) 
        {
            errorln("Error: El payload no es un JSON valido.");
            return;
        }

        // Ejecutamos el Contrato de Datos
        if (doc.containsKey("accion")) 
        {
            String accion_recibida = doc["accion"];
            
           if (accion_recibida == "encender") 
           {
                if (alarma_ON || !sistema_ON) 
                {
                    warnln("BLOQUEO DE PRODUCCIÓN: Orden ignorada. El sistema no está en marcha o hay una alarma.");
                } 
                
                else 
                {
                    infoln("--> Ejecutando: Encendido de actuador principal.");
                    digitalWrite(PIN_ACTUADOR, HIGH);
                }
            }
            else if (accion_recibida == "apagar") 
            {
                infoln("--> Ejecutando: Apagado de actuador.");
                digitalWrite(PIN_ACTUADOR, LOW);
            }
        }
    }
}

void enviarMensajePorTopic(const char* topic, String outgoingMessage) 
{
    mqtt_publish(topic, outgoingMessage);
}