#include "sd_read_write.h"
#include "SD_MMC.h"
#include <time.h>

void on_setup() 
{
    // Configuramos los pines
    pinMode(PIN_ACTUADOR, OUTPUT);
    pinMode(PIN_BOTON_PUERTA, INPUT_PULLUP);
    pinMode(PIN_RESET, INPUT_PULLUP);
    pinMode(PIN_EMERGENCIA, INPUT_PULLUP);
    pinMode(PIN_BOTON_MARCHA, INPUT_PULLUP);
    pinMode(PIN_LED_ALARMA, OUTPUT);
    pinMode(PIN_LED_MARCHA, OUTPUT);
    pinMode(PIN_ALARMA, OUTPUT);
    pinMode(PIN_LDR, INPUT);

    // Estado inicial seguro
    digitalWrite(PIN_ACTUADOR, LOW);
    digitalWrite(PIN_LED_ALARMA, LOW);
    digitalWrite(PIN_LED_MARCHA, LOW);

   // --- SINCRONIZACIÓN DE RELOJ NTP ---
    infoln("Sincronizando reloj interno por NTP...");
    configTime(GMT_OFFSET_SEC, DAYLIGHT_OFFSET_SEC, NTP_SERVER);

   // --- INICIALIZACIÓN DE LA SD INTEGRADA ---
    infoln("Iniciando bus SDMMC con ruteo de pines explícito...");
    SD_MMC.setPins(SD_MMC_CLK, SD_MMC_CMD, SD_MMC_D0);
    if (!SD_MMC.begin("/sdcard", true, true, SDMMC_FREQ_DEFAULT, 5)) 
    {
        warnln("FALLO CAJA NEGRA: Error de montaje SDMMC. Revisa el formato.");
    } 
    else 
    {
        infoln("SD operativa. Sistema de archivos montado.");
        registroSD("SISTEMA: Reinicio de placa ESP32-S3.");
    }

    infoln("Hardware inicializado. Sistema en estado seguro.");
}