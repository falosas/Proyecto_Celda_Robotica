uint8_t ledStatus = 0;

void enviarMensajePorTopic(const char* topic, String outgoingMessage);
